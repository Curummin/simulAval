import math

espaco_amostral = []

for i in range(1,7):
    for j in range(1,7):
        espaco_amostral.append((i, j))

print("Espaco amostral:")
print(espaco_amostral)

valores_X = []

for i, j in espaco_amostral:
    valores_X.append(i + j)

print("\nValores de X = soma:")
print(valores_X)

frequencias = {}

for valor in valores_X:
    if valor in frequencias:
        frequencias[valor] += 1
    else:
        frequencias[valor] = 1

print("\nFrequencias observadas:")
print(frequencias)

# Calculo da esperanca matematica
esperanca = 0

for valor in frequencias:
    prob = frequencias[valor] / 36
    esperanca += valor * prob

print(f"\nEsperanca: {esperanca:.2f}")

# Calculo da variancia
variancia = 0

for valor in frequencias:
    prob = frequencias[valor] / 36
    variancia += (valor - esperanca)**2 * prob

print(f"Variancia: {variancia:.4f}")

# Calculo do desvio padrao
desvio_padrao = math.sqrt(variancia)

print(f"Desvio padrao: {desvio_padrao:.4f}")

