A = {1, 2, 3}
B = {3, 4, 5}

A.add(4)                  # adiciona o elemento 4
print(A)

A.remove(2)               # remove o elemento 2
print(A)

print(A.union(B))         # uniao entre A e B
print(A.intersection(B))  # intersecao entre A e B
print(A.difference(B))    # diferenca A - B


