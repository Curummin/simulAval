import matplotlib.pyplot as plt

# Valores de X e probabilidades acumuladas
x = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
F_X = [1/36, 3/36, 6/36, 10/36, 15/36,
       21/36, 26/36, 30/36, 33/36, 35/36, 1]

# Adiciona pontos extras para representar o comportamento
# antes de x=2 e apos x=12
x = [1] + x + [13]
F_X = [0] + F_X + [1]

# Plota os pontos
plt.plot(x, F_X, 'bo', markersize=5)  # pontos azuis

# Plota as linhas horizontais entre os pontos
for i in range(1, len(x)):
    plt.hlines(F_X[i-1], x[i-1], x[i],
               colors='b', linestyles='solid')

# Adiciona as linhas verticais para indicar os saltos
for i in range(1, len(x) - 1):
    plt.vlines(x[i], F_X[i-1], F_X[i],
               colors='b', linestyles='dotted')

# Configuracoes do grafico
plt.title("Funcao de Distribuicao Acumulada de X")
plt.xlabel("x")
plt.ylabel(r"$F_X(x)$")
plt.grid(True)
plt.show()




