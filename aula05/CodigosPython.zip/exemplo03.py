espaco_amostral = []

for i in range(1,7):
    for j in range(1,7):
        espaco_amostral.append((i,j))

print("Espaco amostral:")
print(espaco_amostral)

valores_X = []

for i, j in espaco_amostral:
    valores_X.append(i + j)

print("\nValores de X = soma:")
print(valores_X)

frequencias = {}

for valor in valores_X:
    if valor in frequencias:
        frequencias[valor] += 1
    else:
        frequencias[valor] = 1

print("\nFrequencias observadas:")
print(frequencias)

