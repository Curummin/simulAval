import math
import numpy as np

espaco_amostral = []

for i in range(1,7):
    for j in range(1,7):
        espaco_amostral.append((i, j))

print("Espaco amostral:")
print(espaco_amostral)

valores_X = []

for i, j in espaco_amostral:
    valores_X.append(i + j)

print("\nValores de X = soma:")
print(valores_X)

frequencias = {}

for valor in valores_X:
    if valor in frequencias:
        frequencias[valor] += 1
    else:
        frequencias[valor] = 1

print("\nFrequencias observadas:")
print(frequencias)


# Conversao para vetores NumPy
x = np.array(sorted(frequencias.keys()))
prob = np.array([frequencias[valor] / 36 for valor in x])

# Calculo da esperanca matematica
esperanca = np.average(x, weights=prob)
print(f"\nEsperanca: {esperanca:.2f}")

# Calculo da variancia
variancia = np.average((x - esperanca)**2, weights=prob)
print(f"Variancia: {variancia:.4f}")

# Calculo do desvio padrao
desvio_padrao = math.sqrt(variancia)
print(f"Desvio padrao: {desvio_padrao:.4f}")


