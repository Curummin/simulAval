import matplotlib.pyplot as plt

# Valores possiveis da variavel aleatoria X
x_values = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]

# Probabilidades correspondentes
probabilities = [1/36, 2/36, 3/36, 4/36, 5/36,
                 6/36, 5/36, 4/36, 3/36, 2/36, 1/36]

# Criar o grafico da FMP
plt.stem(x_values, probabilities,
         basefmt=" ", linefmt="b-", markerfmt="bo")

# Adicionar rotulos
plt.title("Funcao Massa de Probabilidade")
plt.xlabel("Valor de X")
plt.ylabel("P(X=x)")

# Exibir o grafico
plt.grid(True)
plt.show()
